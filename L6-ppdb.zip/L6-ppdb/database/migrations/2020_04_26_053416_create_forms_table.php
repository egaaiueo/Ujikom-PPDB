<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFormsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('forms', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('np');
            $table->integer('nt');
            $table->string('file');
            $table->string('nama');
            $table->string('panggilan');
            $table->string('jk');
            $table->string('ttl');
            $table->string('agama');
            $table->string('cita');
            $table->string('hobby');
            $table->integer('anak');
            $table->integer('jumlah');
            $table->integer('bb');
            $table->integer('tb');
            $table->string('gd');
            $table->string('alamat');    
            $table->string('kel');
            $table->string('kec');
            $table->string('kobtn');
            $table->string('prov');
            $table->string('pos');
            $table->string('no_telp');
            $table->string('mail');
            $table->string('tinggal');
            $table->string('penyakit');
            $table->string('ket');
            $table->string('kelainan');
            $table->string('ayah');
            $table->string('ttl2');
            $table->string('pekerjaan');
            $table->string('pendidikan');
            $table->string('wargama');
            $table->string('telp');
            $table->string('ibu');
            $table->string('ttl3');
            $table->string('pekerjaan2');
            $table->string('pendidikan2');
            $table->string('wargama2');
            $table->string('telp2');
            $table->string('wali');
            $table->string('ttl4');
            $table->string('pekerjaan3');
            $table->string('pendidikan3');
            $table->string('hub');
            $table->string('wargama3');
            $table->string('telp3');
            $table->string('email');
            $table->integer('viip1');
            $table->integer('viip2');
            $table->integer('viiip1');
            $table->integer('viiip2');
            $table->integer('xp1');
            $table->integer('viin1');
            $table->integer('viin2');
            $table->integer('viiin1');
            $table->integer('viiin2');
            $table->integer('xn1');
            $table->integer('viig1');
            $table->integer('viig2');
            $table->integer('viiig1');
            $table->integer('viiig2');
            $table->integer('xg1');
            $table->integer('viim1');
            $table->integer('viim2');
            $table->integer('viiim1');
            $table->integer('viiim2');
            $table->integer('xm1');
            $table->integer('viia1');
            $table->integer('viia2');
            $table->integer('viiia1');
            $table->integer('viiia2');
            $table->integer('xa1');
            $table->integer('viis1');
            $table->integer('viis2');
            $table->integer('viiis1');
            $table->integer('viiis2');
            $table->integer('xs1');
            $table->string('prestasi');
            $table->string('info');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('forms');
    }
}
