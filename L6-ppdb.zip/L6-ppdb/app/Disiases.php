<?php
  
namespace App;
  
use Illuminate\Database\Eloquent\Model;
   
class Disiases extends Model
{
    protected $fillable = [
        'disiases'
    ];
}
