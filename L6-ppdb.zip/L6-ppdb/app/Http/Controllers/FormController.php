<?php

namespace App\Http\Controllers;

use App\Form;
use Illuminate\Http\Request;    

class FormController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('forms.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('forms.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
   public function store(Request $request)
    {
        $request->validate([
            'np' => 'required',
            'nt' => 'required',
            'nama' => 'required',
            'panggilan' => 'required',
            'jk' => 'required',
            'ttl' => 'required',
            'agama' => 'required',
            'cita' => 'required',
            'hobby' => 'required',
            'anak' => 'required',
            'jumlah' => 'required',
            'bb' => 'required',
            'tb' => 'required',
            'gd' => 'required',
            'alamat' => 'required',    
            'kel' => 'required',
            'kec' => 'required',
            'kobtn' => 'required',
            'prov' => 'required',
            'pos' => 'required',
            'no_telp' => 'required',
            'mail' => 'required',
            'tinggal' => 'required',
            'penyakit' => 'required',
            'ket' => 'required',
            'kelainan' => 'required',
            'ayah' => 'required',
            'ttl2' => 'required',
            'pekerjaan' => 'required',
            'pendidikan' => 'required',
            'wargama' => 'required',
            'telp' => 'required',
            'ibu' => 'required',
            'ttl3' => 'required',
            'pekerjaan2' => 'required',
            'pendidikan2' => 'required',
            'wargama2' => 'required',
            'telp2' => 'required',
            'wali' => 'required',
            'ttl4' => 'required',
            'pekerjaan3' => 'required',
            'pendidikan3' => 'required',
            'hub' => 'required',
            'wargama3' => 'required',
            'telp3' => 'required',
            'email' => 'required',
            'viip1' => 'required',
            'viip2' => 'required',
            'viiip1' => 'required',
            'viiip2' => 'required',
            'xp1' => 'required',
            'viin1' => 'required',
            'viin2' => 'required',
            'viiin1' => 'required',
            'viiin2' => 'required',
            'xn1' => 'required',
            'viig1' => 'required',
            'viig2' => 'required',
            'viiig1' => 'required',
            'viiig2' => 'required',
            'xg1' => 'required',
            'viim1' => 'required',
            'viim2' => 'required',
            'viiim1' => 'required',
            'viiim2' => 'required',
            'xm1' => 'required',
            'viia1' => 'required',
            'viia2' => 'required',
            'viiia1' => 'required',
            'viiia2' => 'required',
            'xa1' => 'required',
            'viis1' => 'required',
            'viis2' => 'required',
            'viiis1' => 'required',
            'viiis2' => 'required',
            'xs1' => 'required',
            'prestasi'=>'required',
            'info' => 'required'
        ]);
        
        Form::create($request->all());

        return redirect()->route('forms.index')

                    ->with('setelah',' Setelah melakukan pendaftaran tim kami akan segara mengubungi nomor telepon yang sudah didaftarkan. Pastikan nomor anda aktif, untuk proses pembayaran biaya seleksi dapat dibayar langsung ke sekolah di alamat ini atau melalui transfer ke rekening Bank BNI 082 00 83 086 atas nama SMK Wikrama 1 Garut kemudian kirimkan bukti transfer melalui whatsapp di nomor 089-535-653-1211 (Widya Rahmawati).');        
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Survey  $survey
     * @return \Illuminate\Http\Response
     */
    public function show(Survey $survey)
    {
            
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Survey  $survey
     * @return \Illuminate\Http\Response
     */
    public function edit(Survey $survey)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Survey  $survey
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Survey $survey)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Survey  $survey
     * @return \Illuminate\Http\Response
     */
    public function destroy(Survey $survey)
    {
        //
    }
}
