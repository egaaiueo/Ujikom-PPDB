<?php $__env->startSection('content'); ?>
	<div class="card">
		<form action="<?php echo e(route('forms.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-md-4">
					<input type="text" class="form-control" name="np" placeholder="No. Pendaftaran">
				</div>
				<div class="col-md-4">
					<input type="text" class="form-control" name="nt" placeholder="No. Tes">
				</div>
				<div class="col-md-2">
					<input type="file" class="form-control" name="file">
				</div>
				<div class="col-md-2">
					<p>.jpg/.png</p>
				</div>
			</div>
            <div class="row">
            	<div class="col-md-4">
				<h6><strong>I.DATA CALON MURID</strong></h6>
				<hr>
				<div class="row">
					<div class="col-md-6">
                		<input type="text" class="form-control" name="nama"  placeholder="Nama Lengkap"><br>
					</div>
					<div class="col-md-6">
                		<input type="text" class="form-control" name="panggilan"  placeholder="Nama Panggilan"><br>
					</div>
				</div>
                <input type="radio" class="" name="jk" value="laki-laki">Laki-laki
                <input type="radio" class="" name="jk" value="perempuan">Perempuan<br><br>
                <input type="text" class="form-control"  name="ttl" placeholder="Tempat Tanggal Lahir"><br>
                <input type="text" class="form-control"  name="agama" placeholder="Agama"><br>
                <input type="text" class="form-control"  name="cita" placeholder="Cita - cita"><br>
                <input type="text" class="form-control"  name="hobby" placeholder="Hobby"><br>
                <div class="row">
                    <div class="col-md-6">
                        <input type="text" class="form-control"  name="anak" placeholder="Anak ke"><br>
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control"  name="jumlah" placeholder="Jumlah Saudara"><br>
                    </div>
                </div>
                <div class="row">
					<div class="col-md-4">
                		<input type="text" class="form-control"  name="bb" placeholder="Berat Badan"><br>
					</div>
					<div class="col-md-4">
                		<input type="text" class="form-control"  name="tb" placeholder="Tinggi Badan"><br>
					</div>
					<div class="col-md-4">
                		<input type="text" class="form-control"  name="gd" placeholder="Golongan Darah"><br>
					</div>
				</div>
				</div>

				<div class="col-md-4">
				<h6><strong>II.KETERANGAN TEMPAT TINGGAL</strong></h6>
				<hr>
                <input type="text" class="form-control" name="alamat"  placeholder="Alamat Rumah"><br>
                <input type="text" class="form-control" name="kel"  placeholder="Kelurahan"><br>
                <input type="text" class="form-control"  name="kec" placeholder="Kecamatan"><br>
                <input type="text" class="form-control"  name="kobtn" placeholder="Kota/Kabupaten"><br>
                <div class="row">
                	<div class="col-md-6">
                		<input type="text" class="form-control"  name="prov" placeholder="Provinsi"><br>
					</div>
					<div class="col-md-6">
                		<input type="text" class="form-control"  name="pos" placeholder="Kode Pos"><br>	
                	</div>
            	</div>
                <input type="text" class="form-control"  name="no_telp" placeholder="No. Telepon Rumah"><br>
                <input type="text" class="form-control"  name="mail" placeholder="E-mail"><br>
                <input type="text" class="form-control"  name="tinggal" placeholder="Tinggal Dengan"><br>
                </div>

                <div class="col-md-4">
				<h6><strong>III.KETERANGAN KESEHATAN</strong></h6>
				<hr>
                <select name="penyakit" class="form-control">
                <option value=""></option>
                <?php $__currentLoopData = $Disiases_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data); ?>" name="penyakit"  ><?php echo e($data->disiases); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <input type="text" class="form-control"  name="ket" placeholder="Sebutkan/Kapan"><br>
                <input type="text" class="form-control"  name="kelainan" placeholder="Kelainan Jasmani/Lainnya"><br>
                </div>

                <div class="col-md-4">
				<h6><strong>IV.Data ORANG TUA/WALI</strong></h6>
				<hr>
				<p>A.Ayah</p>
                <input type="text" class="form-control" name="ayah"  placeholder="Nama Ayah"><br>
                <input type="text" class="form-control" name="ttl2"  placeholder="Tempat, Tanggal, Lahir"><br>
                <input type="text" class="form-control"  name="pekerjaan" placeholder="Pekerjaan"><br>
                <input type="text" class="form-control"  name="pendidikan" placeholder="Pendidikan"><br>
                <input type="text" class="form-control"  name="wargama" placeholder="Keraganegaraan/Agama"><br>
                <input type="text" class="form-control"  name="telp" placeholder="No.HP"><br>

                <p>B.Ibu</p>
                <input type="text" class="form-control" name="ibu"  placeholder="Nama Ibu"><br>
                <input type="text" class="form-control" name="ttl3"  placeholder="Tempat, Tanggal, Lahir"><br>
                <input type="text" class="form-control"  name="pekerjaan2" placeholder="Pekerjaan"><br>
                <input type="text" class="form-control"  name="pendidikan2" placeholder="Pendidikan"><br>
                <input type="text" class="form-control"  name="wargama2" placeholder="Keraganegaraan/Agama"><br>
                <input type="text" class="form-control"  name="telp2" placeholder="No.HP"><br>

                <p>C.Wali</p>
                <input type="text" class="form-control" name="wali"  placeholder="Nama Wali"><br>
                <input type="text" class="form-control" name="ttl4"  placeholder="Tempat, Tanggal, Lahir"><br>
                <input type="text" class="form-control"  name="pekerjaan3" placeholder="Pekerjaan"><br>
                <input type="text" class="form-control"  name="pendidikan3" placeholder="Pendidikan"><br>
                <input type="text" class="form-control"  name="hub" placeholder="Hubungan Dengan Murid"><br>
                <input type="text" class="form-control"  name="wargama3" placeholder="Keraganegaraan/Agama"><br>
                <input type="text" class="form-control"  name="telp3" placeholder="No.HP"><br>
                <input type="text" class="form-control"  name="email" placeholder="Alamat E-mail"><br>
                </div>
				
				<div class="col-md-8">
				<h6><strong>V.NILAI RAPOR</strong></h6>
				<hr>
                <p>Mata Pelajaran</p>
                
                	<div class="row">
                	<div class="col-md-6">
                	<p>PAI</p> 
                	
                	<div class="row">
						<div class="col-md-4">	
                			<p>VII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viip1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viip2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>VIII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiip1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiip2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>IX</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="xp1" placeholder="S1">
                		</div>
                	</div><hr>
                	</div>

					<div class="col-md-6">
                	<p>Bahasa Indonesia</p> 
                	
                	<div class="row">
						<div class="col-md-4">	
                			<p>VII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viin1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viin2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>VIII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiin1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiin2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>IX</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="xn1" placeholder="S1">
                		</div>
                	</div><hr>
                	</div>
                	</div>

                	<div class="row">
                	<div class="col-md-6">
                	<p>Inggris</p> 
                	
                	<div class="row">
						<div class="col-md-4">	
                			<p>VII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viig1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viig2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>VIII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiig1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiig2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>IX</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="xg1" placeholder="S1">
                		</div>
                	</div><hr>
                	</div>

					<div class="col-md-6">
                	<p>Matematika</p> 
                	
                	<div class="row">
						<div class="col-md-4">	
                			<p>VII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viim1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viim2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>VIII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiim1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiim2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>IX</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="xm1" placeholder="S1">
                		</div>
                	</div><hr>
                	</div>
                	</div>
					
					<div class="row">
                	<div class="col-md-6">
                	<p>IPA</p> 
                	
                	<div class="row">
						<div class="col-md-4">	
                			<p>VII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viia1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viia2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>VIII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiia1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiia2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>IX</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="xa1" placeholder="S1">
                		</div>
                	</div><hr>
                	</div>
					
					<div class="col-md-6">
                	<p>IPS</p> 
                	
                	<div class="row">
						<div class="col-md-4">	
                			<p>VII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viis1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viis2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>VIII</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiis1" placeholder="S1">
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="viiis2" placeholder="S2">	
                		</div>
                		<div class="col-md-4">	
                			<p>IX</p>
                		</div>
                		<div class="col-md-4">
                			<input type="text" class="form-control" name="xs1" placeholder="S1">
                		</div>
                	</div><hr>
                	</div>
                	</div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <input type="text" class="form-control" name="prestasi" placeholder="Prestasi"><br>
                        </div>
                    </div>

                	<div class="row">
                		<div class="col-md-6">
                			<input type="text" class="form-control" name="info" placeholder="Mengetahui Dari"><br>
                		</div>
                	</div>
		
                </div>
			</div>
			<input type="submit" value="Send" class="btn btn-dark">
        </form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\L6-ppdb\resources\views/forms/create.blade.php ENDPATH**/ ?>